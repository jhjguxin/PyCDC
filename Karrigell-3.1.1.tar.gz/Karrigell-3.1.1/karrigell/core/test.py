import PythonInsideHTML

pih = PythonInsideHTML.PIH("../webapps/index.pih")
print pih.pythonCode()
