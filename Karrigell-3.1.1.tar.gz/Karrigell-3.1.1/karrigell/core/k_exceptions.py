class SCRIPT_END(Exception):
    pass

class HTTP_REDIRECTION(Exception):
    pass