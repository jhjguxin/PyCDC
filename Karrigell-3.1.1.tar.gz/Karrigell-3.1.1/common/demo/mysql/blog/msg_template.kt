<html>

<head>
<title>Message</title>
<link rel="stylesheet" href="$blog_css">
</head>

<body>

<table class="top_line">
<tr>
<td ><a href="/">_[Home]</a></td>
<td align="right">$login_link</td>
</tr>
</table>

$message

</body>
</html>