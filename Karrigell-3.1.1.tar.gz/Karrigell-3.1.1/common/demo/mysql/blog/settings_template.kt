<html>

<head>
<title>$blog_name</title>
<script type="text/javascript" src="/whizzywig/whizzywig.js"></script>
<link rel="stylesheet" href="$blog_css">
</head>

<table class="top_line">
<tr>
<td ><a href="/">_[Home]</a></td>
<td align="right">$login_link</td>
</tr>
</table>

<table class="header">
	<tr><td>
	<h3>_[Editing] <a href="index">$blog_name</a></h3>
	</td></tr>
</table>


<table class="content">
<tr><td>
$form
</td></tr>
</table>

</body>
</html>