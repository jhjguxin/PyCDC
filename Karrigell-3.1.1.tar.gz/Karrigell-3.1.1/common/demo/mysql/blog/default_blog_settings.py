{
'blog_name' : 'My blog',
'blog_css' : '../blog.css',
'title_line1' : 'My personal blog',
'title_line2' : 'Powered by Karrigell',

'links' : [('Karrigell','http://karrigell.sourceforge.net')]
}