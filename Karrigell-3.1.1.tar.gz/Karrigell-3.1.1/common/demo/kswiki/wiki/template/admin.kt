<form action="$this.script_url/remove">
<table border="1">
<tr><th>&nbsp;</th><th>Page</th></tr>
$data.pagelist
</table>
<input name="subm" type="submit" value="Remove selected pages">
<input name="subm" type="submit" value="Cancel">
</form>
