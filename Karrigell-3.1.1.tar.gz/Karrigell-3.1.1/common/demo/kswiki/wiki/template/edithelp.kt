<pre><tt>
'''_[bold]''' = <b>_[bold]</b>  ''_[italic]'' = <i>_[italic]</i>  ^_[superscript] = <sup>_[superscript]</sup>
* = _[unordered list]  ** = _[second level] etc
# = _[ordered list]    ## = _[second level] etc
! = &lt;H1&gt; !! = &lt;H2&gt; etc.
_[line begins with ---- = horizontal rule]
_[line begins with { + "name"] = _[apply class "name" from wiki.css]
_[line begins with }] = _[stop using class]
_[TwoCapitals creates a link to the document called] <a href="javascript:alert('Link to TwoCapitals')">_[TwoCapitals]</a>
_ThisIsNotAWikiWord _[because it starts with] _
[_[link target]|http://host:service/home.html] _[creates a link to the specified url]
[_[link target]|WikiName] _[creates a link to the specified page in the wiki]
http://host/path/index.htm, mailto:user@host, ftp://host&nbsp; _[are converted to hyperlinks]
img://host/path/image.jpg _[embeds an image]
imgl = _[left aligned image], imgc = _[centered image], imgr = _[right aligned image]
</tt></pre>
