<h2>Removing pages</h2>
<b>These pages have been removed:</b>
<ul>
$data.pagelist
</ul>
$data.msg
<p />
<a href="index">Back</a>
