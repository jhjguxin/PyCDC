$data.html
<br>
<br>
<HR>
<a href="$this.script_url/edit/$data.pageName">_[Edit this document]</a>
<br>
<i>_[Version] : $page.version</i> - 
<i>_[Last modified] : $data.lastmodif &nbsp;_[Visited] $page.nbvisits _[times]</i>
