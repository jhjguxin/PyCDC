import urlparse
Login(valid_in="/",redir_to=urlparse.urljoin(THIS.script_url,"index.pih"))