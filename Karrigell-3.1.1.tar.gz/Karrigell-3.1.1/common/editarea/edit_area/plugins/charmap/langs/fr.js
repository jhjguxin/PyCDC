editArea.add_lang("fr",{
charmap_but: "Clavier visuel",
charmap_title: "Clavier visuel",
charmap_choose_block: "choix du language",
charmap_insert:"ins&eacute;rer ce caract&egrave;re"
});
