RESPONSE['Content-Type']='text/plain'
print "Bonjour tout le monde !"