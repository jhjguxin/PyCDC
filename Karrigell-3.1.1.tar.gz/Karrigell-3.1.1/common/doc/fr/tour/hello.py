print "Bonjour tout le monde !"
