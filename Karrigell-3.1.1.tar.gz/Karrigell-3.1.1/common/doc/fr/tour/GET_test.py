print "J'ai re�u la cha�ne de requ�te",REQUEST
print "<br>Tu t'appelles %s, pas vrai ?" %_foo