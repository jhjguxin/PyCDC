Session().name = _surname
print "Bonjour %s" %_surname
print '<br>Veuillez <a href="session2.py">saisir</a> votre commande'
