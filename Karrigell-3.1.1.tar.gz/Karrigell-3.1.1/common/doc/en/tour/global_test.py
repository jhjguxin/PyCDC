print aaa.message
print "<br>",aaa.value
aaa.value += 1
