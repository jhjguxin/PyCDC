RESPONSE['Content-Type']='text/plain'
print 'Hello World !'