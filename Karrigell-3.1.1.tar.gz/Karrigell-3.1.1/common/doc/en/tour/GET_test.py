print "I received the query string",REQUEST
print "<br>Your name is %s, isn't it?" %_foo