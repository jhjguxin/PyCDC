message = "this is a global module "
value = 0