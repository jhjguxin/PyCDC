print "Hello world !"
