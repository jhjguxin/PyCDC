# script with NameError
print blah