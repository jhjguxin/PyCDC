Session().name = _surname
print "Hello %s" %_surname
print '<br>Please <a href="session2.py">enter</a> your order'
