print "I received the post data",REQUEST
print "<br>Your name is %s, isn't it?" %_foo