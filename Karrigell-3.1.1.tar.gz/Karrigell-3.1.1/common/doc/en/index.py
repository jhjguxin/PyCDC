SET_UNICODE_OUT('iso-8859-1')
print KT('index.tmpl',version=REQUEST_HANDLER.version,other_language="Fran�ais")