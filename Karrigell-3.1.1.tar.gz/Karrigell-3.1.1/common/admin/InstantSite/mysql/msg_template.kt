<html>
<head>
<link rel="stylesheet" href="../manage.css">
</head>

<body>
$content
</body>
</body>

</html>