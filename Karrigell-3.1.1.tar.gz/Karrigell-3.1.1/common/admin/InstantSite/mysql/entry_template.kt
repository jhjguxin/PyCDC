<html>
<head>
<link rel="stylesheet" href="../manage.css">
<link rel="stylesheet" href="../calendar.css">
<script src="../calendar.js"></script>
</head>

<body>
<table width="50%">
<tr>
<td>_[Host] $host</td>
<td>_[Database] $db_name</td>
</table>

Table $table_name
$table_menu

$content
</body>

</html>