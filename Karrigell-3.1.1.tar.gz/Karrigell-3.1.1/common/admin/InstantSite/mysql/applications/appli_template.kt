<html>
<head>
<link rel="stylesheet" href="../manage.css">
<link rel="stylesheet" href="../calendar.css">
<script src="../calendar.js"></script>
</head>

<body>
$header
$content
$add_record
</body>

</html>