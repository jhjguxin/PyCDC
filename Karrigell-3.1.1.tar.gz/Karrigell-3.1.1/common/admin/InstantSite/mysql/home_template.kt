<html>
<head>
<link rel="stylesheet" href="../manage.css">
</head>

<body>
<table width="50%">
<tr>
<td>_[Host] $host</td>
</table>
<p>
$content
</body>
</body>

</html>