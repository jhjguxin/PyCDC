<html>
<head>
<link rel="stylesheet" href="$stylesheet">
</head>

<body>
<a href="/" target="_top">_[Home]</a><p>
<h3><a href="../index" target="_top">_[MySQL manager]</a></h3>
$content
</body>
</body>

</html>