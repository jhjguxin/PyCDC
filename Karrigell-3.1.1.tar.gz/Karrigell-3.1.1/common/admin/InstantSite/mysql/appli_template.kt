<html>
<head>
<link rel="stylesheet" href="../manage.css">
</head>

<body>
$header
$content
$add_record
</body>

</html>