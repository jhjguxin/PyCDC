print "Content-type:text/html"
print 
print "<b>bonjour</b>"