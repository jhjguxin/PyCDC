if (window.navigator.platform.indexOf('Win')>-1)
{ pf = 'w' } else { pf = 'u' }

