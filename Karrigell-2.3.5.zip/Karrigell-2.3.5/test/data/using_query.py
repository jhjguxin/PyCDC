print "<br>Spam is ",QUERY["spam"]
if QUERY.has_key("animal"):
    print "<br>Animal is ",str(QUERY["animal"])
