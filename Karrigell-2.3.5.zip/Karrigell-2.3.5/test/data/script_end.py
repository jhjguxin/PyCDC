myVar=10
print myVar
raise SCRIPT_END
# rest of code - won't be run
print myVar
