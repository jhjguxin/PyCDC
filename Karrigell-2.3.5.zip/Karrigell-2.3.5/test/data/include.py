Include("header.htm")
print "--------------"
print " page content "
print "--------------"
Include("footer.py")    
