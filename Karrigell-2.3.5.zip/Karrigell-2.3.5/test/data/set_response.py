RESPONSE['conteNT-Type']='text/plain'
print 'bonjour'