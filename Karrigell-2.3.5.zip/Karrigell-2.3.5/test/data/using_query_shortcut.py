print "<br>Spam is ",_spam
if QUERY.has_key("animal"):
    print "<br>Animal is ",str(_animal)
