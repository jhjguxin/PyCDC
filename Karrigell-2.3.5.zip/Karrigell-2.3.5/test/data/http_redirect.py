raise HTTP_REDIRECTION, "/elsewhere"
