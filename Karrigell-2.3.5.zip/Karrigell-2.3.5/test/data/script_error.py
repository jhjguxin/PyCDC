a = "xoxox"
print a[5]
