name="Brian"
print "The life of "
Include("whoseName.py")
