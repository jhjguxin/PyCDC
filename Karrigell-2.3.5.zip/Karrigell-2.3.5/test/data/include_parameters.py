items=(('Up','up.py'),
       ('Down','down.py'),
       ('Left','left.py'),
       ('Right','right.py'))
Include("menu.py", items=items, selected='up.py')
