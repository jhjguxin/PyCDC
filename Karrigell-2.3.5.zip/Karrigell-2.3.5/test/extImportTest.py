import sys
sys.path.append(r"c:\Mes documents\Pierre\Programmes Python")

import extImport
print extImport.var