File not found
Fichier non trouvé
Feb

Document created, URL follows

Aug

Wed

Sun

Fri

Administration

Jan

Server does not support this operation

The gateway server did not receive a timely response

Nothing matches the given URI
Rien ne correspond à l'URI fournie
Request fulfilled, document follows

Oct

No file matching url 
Aucun fichier ne correspond à l'url
No payment -- see charging schemes

Mar

Object moved permanently -- see URI list

Request accepted, processing continues off-line

Object moved -- see Method and URL list

May

Error response
Réponse d'erreur
Authentication error
Erreur d'authentification
Jun

Jul

Error code
Code erreur
Mon

Nov

Server got itself in trouble

Tue

Thu

Message: 

Request fulfilled, nothing follows

Dec

Request forbidden -- authorization will not help

Document has not changed since given time

The server cannot process the request due to a high load

Sep

Apr

Request fulfilled from cache

Error for
Erreur pour
Object moved temporarily -- see URI list

Directory list forbidden
Listage du répertoire interdit
No permission -- see authorization schemes

Bad request syntax or unsupported method

Error code explanation: 
Explication du code erreur:
Sat

