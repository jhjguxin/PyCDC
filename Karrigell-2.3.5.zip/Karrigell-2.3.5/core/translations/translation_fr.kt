File not found
Fichier non trouvé
Feb
Fév
Document created, URL follows

Aug
Aou
Wed
Mer
Sun
Dim
Fri
Ven
Jan
Jan
Server does not support this operation

The gateway server did not receive a timely response

Nothing matches the given URI

Request fulfilled, document follows

Oct
Oct
No payment -- see charging schemes

Mar
Mar
Object moved permanently -- see URI list

Request accepted, processing continues off-line

Object moved -- see Method and URL list

May
Mai
Error response
Réponse d'erreur
Jun
Jun
Jul
Jul
Error code
Code erreur
Mon
Lun
Nov
Nov
Server got itself in trouble
Le serveur a rencontré un problème
Tue
Mar
Thu
Jeu
Message: 
Message:
Request fulfilled, nothing follows

Dec
Déc
Request forbidden -- authorization will not help

Document has not changed since given time

The server cannot process the request due to a high load

Sep
Sep
Apr
Avr
Request fulfilled from cache

Error for
Erreur pour
Object moved temporarily -- see URI list

Directory list forbidden
Listage du répertoire interdit
No permission -- see authorization schemes

Bad request syntax or unsupported method

Error code explanation: 
Explication du code erreur:
Sat
Sam
