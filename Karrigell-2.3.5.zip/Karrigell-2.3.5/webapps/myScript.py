# -*- coding: latin-1 -*-
import time
myName = "I am a global script"
u_str = unicode('d�d�','latin-1')