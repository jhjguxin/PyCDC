import time
myName="Pierre"
yourName="Anne"

