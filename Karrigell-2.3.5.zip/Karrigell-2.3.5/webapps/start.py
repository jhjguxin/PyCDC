#!python
print "Content-type: text/html"
print
import os
print os.environ