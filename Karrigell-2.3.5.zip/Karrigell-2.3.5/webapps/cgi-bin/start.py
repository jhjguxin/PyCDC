#!python
print "Content-type: text/html"
print
print "environnement"
import os
print os.environ