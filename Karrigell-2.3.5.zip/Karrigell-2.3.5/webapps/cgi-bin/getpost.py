<form action="?one=1" method="post">
<input  type="hidden" name="two" value="2" />
</form>