# this file is used by Apache / mod_python
# so that the directive "PythonHandler webapps.ApacheHandler"
# find the module ApacheHandler.py