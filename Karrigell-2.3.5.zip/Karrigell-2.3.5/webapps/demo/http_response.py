RESPONSE['Location'] = "http://www.karrigell.com"
raise HTTP_RESPONSE(301,"Redirection")
