print "<html>\n<body>\n"

myVar=10
print "My var is ",myVar
raise SCRIPT_END
print bonjour # the script would fail there if there wasn't a SCRIPT_END exception

print "</body>\n</html>"