print 'Script 3'
Include ("RecursionErrorTest1.py")