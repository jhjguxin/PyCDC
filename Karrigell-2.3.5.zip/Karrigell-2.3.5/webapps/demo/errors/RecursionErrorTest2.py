print 'Script 2'
Include ("RecursionErrorTest3.py")