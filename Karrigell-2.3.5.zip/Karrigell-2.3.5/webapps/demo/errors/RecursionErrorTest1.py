print 'Script 1'
Include ("RecursionErrorTest2.py")