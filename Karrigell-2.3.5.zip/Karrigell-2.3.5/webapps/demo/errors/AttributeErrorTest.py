a="hello"
print a.x
