print 'Script 1'
Include ("ErrorInIncludedTest2.py")