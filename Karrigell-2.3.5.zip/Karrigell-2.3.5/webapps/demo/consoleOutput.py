import k_utils
k_utils.trace('essai')