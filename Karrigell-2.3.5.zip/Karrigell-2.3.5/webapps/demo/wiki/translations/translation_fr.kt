apply class "name" from wiki.css
appliquer la classe "nom" dans wiki.css
Case sensitive
Respecter la casse
Search
Rechercher
ordered list
liste ordonnée
Must begin with a Capital and have at least another one inside
Doit commencer par une lettre capitale et en avoir au moins une autre à l'intérieur
Administrator
Administrateur
Exit without saving
Sortie sans sauvegarder
Full word
Mot entier
unordered list
liste non ordonnée
Browse the existing pages
Parcourir les pages existantes
Welcome to BuanBuan
Bienvenue sur BuanBuan
italic
italique
Save changes
Sauvegarder les changements
TwoCapitals creates a link to the document called
DeuxCapitales crée un lien vers le document appelé
TwoCapitals
DeuxCapitales
stop using class
fin d'utilisation de la classe
bold
gras
Add new page
Ajouter une nouvelle page
Page name
Nom de la page
line begins with { + name
ligne commence par { + nom
line begins with ---- = horizontal rule
ligne commence par ---- = ligne horizontale
BuanBuan is a simple Wiki server
BuanBuan est un serveur wiki simple
Editing file
Edition de fichier
line begins with }
ligne commence par }
are converted to hyperlinks
sont converties en liens
is not a valid link name - 
n'est pas un nom valide
