print "Hello Karrigell !"
print 41*' '
