print HEADERS
print '<br>Cookie'
print SET_COOKIE
#print SET_COOKIE["user"].value
print SET_COOKIE["userid"].value