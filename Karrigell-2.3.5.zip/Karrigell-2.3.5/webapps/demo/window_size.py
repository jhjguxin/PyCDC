print "Window size : "
print "height",_width
print ", width",_height