
print ''' 
<form id="editor" method="post" action="textArea2.py"> 
<textarea name="text" rows="25" wrap=physical></textarea> 
<br> 
<input type="submit" value="Ok"> 
</form> 
''' 
