RESPONSE['conteNT-Type']='text/plain'
print 'Hello Karrigell !'