so=Session()
so.close()
raise HTTP_REDIRECTION,"index.pih"