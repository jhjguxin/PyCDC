import b
value = b.value
print value 