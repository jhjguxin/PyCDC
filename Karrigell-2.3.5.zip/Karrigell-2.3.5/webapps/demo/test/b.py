
import c
value = c.value 