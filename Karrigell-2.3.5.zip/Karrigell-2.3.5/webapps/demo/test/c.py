# c.py
value = 'haha: in c.py' 