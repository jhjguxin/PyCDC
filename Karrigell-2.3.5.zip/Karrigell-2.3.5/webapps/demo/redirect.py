
raise HTTP_REDIRECTION,"http://perso.wanadoo.fr/per.kentel/index.html"
