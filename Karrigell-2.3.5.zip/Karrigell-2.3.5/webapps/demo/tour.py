src = open('tour.htm').read()
RESPONSE['Content-type'] = "text/html; charset:utf-8"
print src