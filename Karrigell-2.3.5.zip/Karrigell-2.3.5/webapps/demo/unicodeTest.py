# -*- coding: UTF-8 -*-
print '�criture'
