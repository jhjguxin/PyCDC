Session().close()

raise HTTP_REDIRECTION,"index.pih"