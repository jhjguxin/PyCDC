print "Value of THIS.name in script includeFooter.py : %s" %THIS.name
print "<p>"